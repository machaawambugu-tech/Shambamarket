export const CATEGORIES = [
  { name: "Fresh Produce", icon: "🥬", subs: ["Fruits", "Vegetables", "Nuts"] },
  { name: "Crops & Grains", icon: "🌾", subs: ["Starchy Foods", "Grains", "Cereals", "Legumes", "Spices", "Herbal Products"] },
  { name: "Farm Tools & Equipment", icon: "🚜", subs: ["Hand Tools", "Sprayers", "Irrigation Equipment", "Tractors", "Farm Machinery"] },
  { name: "Agricultural Inputs & Fertilizers", icon: "🌱", subs: ["Seeds", "Seedlings", "Fertilizers", "Compost & Manure", "Approved Crop Protection", "Animal Feed"] },
  { name: "Livestock & Poultry", icon: "🐄", subs: ["Cattle", "Goats", "Sheep", "Pigs", "Chickens", "Ducks", "Turkeys", "Rabbits", "Other Livestock"] },
  { name: "Animal & Farm Products", icon: "🥚", subs: ["Milk", "Eggs", "Honey", "Wool", "Hides & Skins", "Processed Farm Products"] },
  { name: "Farm Services", icon: "🧑🏽‍🌾", subs: ["Tractor Hire", "Ploughing", "Planting", "Harvesting", "Transport", "Irrigation Installation", "Agricultural Consulting"] }
];
export const COUNTIES = ["Baringo","Bomet","Bungoma","Busia","Elgeyo-Marakwet","Embu","Garissa","Homa Bay","Isiolo","Kajiado","Kakamega","Kericho","Kiambu","Kilifi","Kirinyaga","Kisii","Kisumu","Kitui","Kwale","Laikipia","Lamu","Machakos","Makueni","Mandera","Marsabit","Meru","Migori","Mombasa","Murang'a","Nairobi","Nakuru","Nandi","Narok","Nyamira","Nyandarua","Nyeri","Samburu","Siaya","Taita-Taveta","Tana River","Tharaka-Nithi","Trans Nzoia","Turkana","Uasin Gishu","Vihiga","Wajir","West Pokot"];
