# ShambaMarket — rebuild package

## Files
Upload all files in this folder to the ROOT of your GitHub Pages repository, replacing the old app files. Keep the filenames and capitalization exactly as shown.

## 1) Connect Supabase
Open `supabase-config.js` and replace `PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY_HERE` with your project's **publishable** key (the `sb_publishable_...` key). Never use a service-role/secret key in browser code.

## 2) Database setup
In Supabase Dashboard → SQL Editor, run `supabase-schema.sql`. It creates the profiles/listings tables, storage bucket, and starter security policies. Review the file before running. Do not paste secrets into SQL or public code.

## 3) Authentication URL settings
Supabase Dashboard → Authentication → URL Configuration:
- Site URL: your GitHub Pages website URL
- Add the same website URL to Redirect URLs
- Email confirmation and password reset require the correct redirect URL.

## 4) Admin
Create and confirm your normal account first. In Supabase Table Editor → `profiles`, change your own `role` to `admin` after verifying the account ID. Never grant admin from a front-end email check. Admin role changes must be performed by a trusted project owner.

## 5) GitHub Pages
Upload/commit all files in the repository root. GitHub → Settings → Pages should publish from the `main` branch, `/ (root)`. Wait for deployment, then hard refresh the live site.

## Important
- The app uses `listings`, `profiles`, `conversations`, `conversation_participants`, and `messages`.
- A photo bucket named `listing-photos` is used.
- Public browsing is designed to work without logging in; protected actions require sign-in.
- The starter messaging interface expects the `create_conversation` RPC included in the SQL file.
- This is a starter implementation. Test with non-sensitive sample listings before sharing publicly. Never claim end-to-end encryption; database row-level security is access control, not end-to-end encryption.
