-- ShambaMarket initial schema
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text not null default '',
  role text not null default 'buyer' check (role in ('buyer','farmer','both','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  product_name text not null,
  category text not null,
  subcategory text not null default '',
  price numeric(12,2) not null default 0 check (price >= 0),
  quantity numeric(12,2) not null default 0 check (quantity >= 0),
  unit text not null default 'kg',
  condition text not null default 'Fresh',
  photo_url text,
  county text not null default '',
  town text not null default '',
  phone text not null default '',
  farmer_name text not null default '',
  description text not null default '',
  status text not null default 'published' check (status in ('published','draft','sold','archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.listings enable row level security;

drop policy if exists "Public can read published listings" on public.listings;
create policy "Public can read published listings" on public.listings for select using (status = 'published' or owner_id = auth.uid());
drop policy if exists "Signed-in farmers can create listings" on public.listings;
create policy "Signed-in farmers can create listings" on public.listings for insert to authenticated with check (owner_id = auth.uid());
drop policy if exists "Owners can update listings" on public.listings;
create policy "Owners can update listings" on public.listings for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());
drop policy if exists "Owners can delete listings" on public.listings;
create policy "Owners can delete listings" on public.listings for delete to authenticated using (owner_id = auth.uid());

drop policy if exists "Users can read own profile" on public.profiles;
create policy "Users can read own profile" on public.profiles for select to authenticated using (id = auth.uid());
drop policy if exists "Users can insert own profile" on public.profiles;
create policy "Users can insert own profile" on public.profiles for insert to authenticated with check (id = auth.uid() and role <> 'admin');
drop policy if exists "Users can update own non-admin profile" on public.profiles;
create policy "Users can update own non-admin profile" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid() and (role <> 'admin' or (select role from public.profiles p where p.id = auth.uid()) = 'admin'));

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
 insert into public.profiles (id, full_name, role)
 values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), coalesce(new.raw_user_meta_data->>'role','buyer'))
 on conflict (id) do nothing;
 return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('listing-photos','listing-photos',true,5242880,array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;
drop policy if exists "Public can view listing photos" on storage.objects;
create policy "Public can view listing photos" on storage.objects for select using (bucket_id = 'listing-photos');
drop policy if exists "Users upload own listing photos" on storage.objects;
create policy "Users upload own listing photos" on storage.objects for insert to authenticated with check (bucket_id = 'listing-photos' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Users update own listing photos" on storage.objects;
create policy "Users update own listing photos" on storage.objects for update to authenticated using (bucket_id = 'listing-photos' and (storage.foldername(name))[1] = auth.uid()::text) with check (bucket_id = 'listing-photos' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Users delete own listing photos" on storage.objects;
create policy "Users delete own listing photos" on storage.objects for delete to authenticated using (bucket_id = 'listing-photos' and (storage.foldername(name))[1] = auth.uid()::text);

create table if not exists public.conversations (
 id uuid primary key default gen_random_uuid(),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create table if not exists public.conversation_participants (
 conversation_id uuid not null references public.conversations(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 joined_at timestamptz not null default now(),
 primary key (conversation_id,user_id)
);
create table if not exists public.messages (
 id uuid primary key default gen_random_uuid(),
 conversation_id uuid not null references public.conversations(id) on delete cascade,
 sender_id uuid not null references auth.users(id) on delete cascade,
 body text not null check (char_length(trim(body)) between 1 and 4000),
 created_at timestamptz not null default now()
);
create index if not exists messages_conversation_created_idx on public.messages(conversation_id,created_at);
alter table public.conversations enable row level security;
alter table public.conversation_participants enable row level security;
alter table public.messages enable row level security;

drop policy if exists "Members can read conversations" on public.conversations;
create policy "Members can read conversations" on public.conversations for select to authenticated using (exists(select 1 from public.conversation_participants cp where cp.conversation_id=conversations.id and cp.user_id=auth.uid()));
drop policy if exists "Members can read memberships" on public.conversation_participants;
create policy "Members can read memberships" on public.conversation_participants for select to authenticated using (user_id=auth.uid());
drop policy if exists "Members can read messages" on public.messages;
create policy "Members can read messages" on public.messages for select to authenticated using (exists(select 1 from public.conversation_participants cp where cp.conversation_id=messages.conversation_id and cp.user_id=auth.uid()));
drop policy if exists "Members can send their own messages" on public.messages;
create policy "Members can send their own messages" on public.messages for insert to authenticated with check (sender_id=auth.uid() and exists(select 1 from public.conversation_participants cp where cp.conversation_id=messages.conversation_id and cp.user_id=auth.uid()));

create or replace function public.create_conversation(p_other_user uuid)
returns uuid language plpgsql security definer set search_path = '' as $$
declare v_me uuid := auth.uid(); v_conversation_id uuid;
begin
 if v_me is null then raise exception 'You must sign in first'; end if;
 if p_other_user is null or p_other_user=v_me then raise exception 'Choose another user'; end if;
 if not exists(select 1 from auth.users where id=p_other_user) then raise exception 'User not found'; end if;
 insert into public.conversations default values returning id into v_conversation_id;
 insert into public.conversation_participants(conversation_id,user_id) values(v_conversation_id,v_me),(v_conversation_id,p_other_user);
 return v_conversation_id;
end;
$$;
revoke all on function public.create_conversation(uuid) from public;
grant execute on function public.create_conversation(uuid) to authenticated;
